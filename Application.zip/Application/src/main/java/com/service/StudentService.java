package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.controller.Student;

@Service
public class StudentService {
	@Autowired
	private StudentRepository studentRepository;
	public void registerStudent(Student student) {
		studentRepository.save(student);{
			StudentRepository studentRepository2 = new studentRepository();
			studentRepository2.save(student);
		}
		
		public void updateStudent(Long id, Student student1) {
			Student existing student= studentRepository.findById(id)
					orElseThrow(()-> new RuntimeException("Student not fount"));
			
			existingStudent.setName(student.getName());
			studentRepository.save(existingStudent);
			
			
		}
	}
		
		@Repository
		public interface StudentRepository extends JpaRepository<Student,Long>{
	
		}

}
