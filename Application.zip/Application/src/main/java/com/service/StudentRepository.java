package com.service;

import com.controller.Student;

public class StudentRepository implements com.service.StudentService.StudentRepository {

	public void save(Student student) {
		// TODO Auto-generated method stub
		
	}

	public Student findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
