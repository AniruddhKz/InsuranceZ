package com.aspect;

import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Aspect
@Component
public class LoggingAspect {
	private static final org.slf4j.Logger logger= LoggerFactory.getLogger(LoggingAspect.class);
	
	@Before("execution(*com.example.controller.*.*(.."))")"

public voidnlogBefore(JoinPoint joinPoint) {
	logger.info("Before method: "+joinPoint.getSignature().getName());
}
}

@ControllerAdvice
public class GlobalExceptionHandler{
	
	private static final Logger logger=LoggerFactory.getLogger(GlobalExceptionHandler.class);
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleException(Exception ex){
		logger.error("Exception occurred, +ex.getMessage());
	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
			body("error occurred");
	
}
	

}
