package com.jmo;

public class Student {

}
