package com.jmo;

public class MockitoJnuitRunner {

}
