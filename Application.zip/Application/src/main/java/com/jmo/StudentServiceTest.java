package com.jmo;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.controller.Student;
import com.controller.StudentService;
import com.entity.StudentRepository;
import com.sun.tools.javac.util.List;
import com.test.InjectMocks;
import com.test.Mock;
@RunWith(MockitoJnuitRunner.class)
public class StudentServiceTest {
	@Mock
	private StudentRepository studentRepository;
	@InjectMocks
	private StudentService studentService;
	@Test
	public void testFindAllStudents() {
		
		java.util.List<Student> students=Arrays.asList(new Student(), new Student());
		when(studentRepository.Student()).thenReturn(students);
		List<Student> result=studentService.getAllStudents();
		assertEquals(2, result.get(0).getName());
		assertEquals("Bob", resultget(1).getName());
		
		}
	private Object resultget(int i) {
		// TODO Auto-generated method stub
		return null;
	}
		}






