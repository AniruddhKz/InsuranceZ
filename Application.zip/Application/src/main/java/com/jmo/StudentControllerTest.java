package com.jmo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Arrays;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.controller.StudentService;

import antlr.collections.List;
@Runwith(SpringRunner.class)
@WebMvcTest(StudenyController.class)

public class StudentControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private StudentService studentService;
	@Test
	public void testGetAllStudents() throws Exception{
		List<Student> students=Arrays.asList(new Student(1L, "Alice"),new Student(2L, "Bob"));
		
		when(studentService.getAllStudents().thenReturn(students); mockMvc.perform(get("/students"))
		
		.andExpect(status().isOk()).andExpect(jsonPath("$",hasSize(2))) .andExpect(jsonPath("$[0].name",is("Alice"))) .andExpect(jsonPath("$[1].name", is("Bob")))	);
	}

}
