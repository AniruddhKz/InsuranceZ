package com.jmo;

public @interface MockBean {

}
