package com.jmo;

public @interface WebMvcTest {

}
