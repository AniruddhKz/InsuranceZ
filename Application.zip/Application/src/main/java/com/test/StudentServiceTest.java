import static org.mockito.Mockito.*;
import java.util.*;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.controller.Student;
import com.controller.StudentService;
import com.entity.StudentRepository;

@RunWith(MockitoJUnitRunner.class)
public class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    @Test
    public void testFindAllStudents() {
        // Mock data
        List<Student> students = Arrays.asList(
            new Student(),
            new Student()
        );

        // Mock repository behavior
        when(studentRepository.findAll()).thenReturn(students);

        // Call the service method
        List<Student> result = studentService.getAllStudents();

        // Assert the result
        assertEquals(2, result.size());
        assertEquals("Alice", result.get(0).getName());
        assertEquals("Bob", result.get(1).getName());
    }

	private Object when(List<Student> all) {
		// TODO Auto-generated method stub
		return null;
	}
}
