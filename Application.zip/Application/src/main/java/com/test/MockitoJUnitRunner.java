package com.test;

public class MockitoJUnitRunner {

}
