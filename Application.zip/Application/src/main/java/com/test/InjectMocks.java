package com.test;

public @interface InjectMocks {

}
