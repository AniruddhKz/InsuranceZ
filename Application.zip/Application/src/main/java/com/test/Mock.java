package com.test;

public @interface Mock {

}
