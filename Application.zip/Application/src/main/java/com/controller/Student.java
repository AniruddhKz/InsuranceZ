package com.controller;

public class Student {

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setAge(int i) {
		// TODO Auto-generated method stub
		
	}

}
