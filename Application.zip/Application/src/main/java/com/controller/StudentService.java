package com.controller;

import com.sun.tools.javac.util.List;

public class StudentService {

	public void updateStudent(Long id, Student student) {
		// TODO Auto-generated method stub
		
	}

	public void registerStudent(Student student) {
		// TODO Auto-generated method stub
		
	}

	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return null;
	}

}
