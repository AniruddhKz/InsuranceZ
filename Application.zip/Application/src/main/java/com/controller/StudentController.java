package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/students")
public class StudentController {
	
	@Autowired
	private StudentService StudentService;

	public StudentService getStudentService() {
		return StudentService;
	}

	public void setStudentService(StudentService studentService) {
		StudentService = studentService;
	}
	
	@PostMapping("/register")
	public ResponseEntity<?> registerStudent(@RequestBody Student student){
		
		StudentService.registerStudent(student);
		return ResponseEntity.ok("Student registered ");
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateStudent (@PathVariable Long id, @RequestBody Student student){
		
		StudentService.updateStudent(id, student);
		return ResponseEntity.ok("success");
	}
	}
