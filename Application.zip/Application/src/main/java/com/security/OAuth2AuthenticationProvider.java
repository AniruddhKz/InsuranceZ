package com.security;

public class OAuth2AuthenticationProvider {

}
