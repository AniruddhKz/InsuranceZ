package com.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import com.controller.Student;



public interface StudentRepository extends JpaRepository<Student, Long> {

	List<Student> findByName(String name);
	List<Student> findByAge(int age);
	@Query("select s from Student s where s.age>=: minAge AND s.age<=: maxAge")
	List<Student> findAgeRange(int minAge, int maxAge);
	Object Student();

}
