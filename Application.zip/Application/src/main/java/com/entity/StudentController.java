package com.entity;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.controller.Student;
@RestController
public class StudentController {
	
	@Autowired
	private StudentRepository studentRepository;
	@GetMapping("/students/save")
	public Student saveStudent() {
		Student student=new Student();
		student.setName("John");
		student.setAge(100);
		return studentRepository.save(student);
	}
	@GetMapping("/students/byName")
	public List<Student>getStudentByName(){
		
		return studentRepository.findByName("John");
	}
}
